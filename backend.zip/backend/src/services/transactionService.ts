import { getTransactions, setTransactions } from "../datastore/transactions.js";
import { CreateTransactionInput, Transaction } from "../types/transaction.js";
import { generateId } from "./generateId.js";

// GET
export const fetchTransactions = () => {
    return getTransactions();
}

export const fetchTransaction = (transactionId: number) => {
    const transactions = getTransactions();

    const transaction = transactions.find((transaction) => 
        transaction.id === transactionId);

    if (!transaction){
        return undefined;
    }

    return transaction;
}

//POST
export const makeTransaction = (input: CreateTransactionInput) : Transaction | undefined => {
    const transactions = getTransactions();
    const currentMaxId = transactions.length === 0 ?
        0
        : Math.max(...transactions.map((transaction) => transaction.id));

    const transaction: Transaction = {
        id: generateId(currentMaxId),
        ...input,
    }

    setTransactions([...transactions, transaction]);

    return transaction;
}

// PUT
export const removeTransaction = (id: number): boolean => {
    const transactions = getTransactions();
    const filteredtransactions = transactions.filter((transaction) => transaction.id !== id);

    if (transactions.length == filteredtransactions.length){
        return false;
    }

    setTransactions(filteredtransactions);
    return true;
}
